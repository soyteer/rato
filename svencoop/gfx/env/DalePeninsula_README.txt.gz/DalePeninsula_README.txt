Dale Peninsula Sky Box

by Ken "Doc Mojo" Musgrave and Armands Auseklis

Armands' legendary planet Dale, with minor sky and water tweaks by Doc Mojo.  I wanna go swimming here!

	-Doc Mojo
