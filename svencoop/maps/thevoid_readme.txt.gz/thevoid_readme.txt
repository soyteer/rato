                      *** The Void ***

                     by Hezus (c) 2007


I've made this map in about 2 days. Sph!nx showed me a few developement textures he made and I instantly started making a small map called DevWorld with the textures. It outgrew itself and I renamed it to : The Void.

The Void is an unknown area where everything floats in nothingness. The world consists out of different coloured thin plates which are the only walkways. Each colour has a different ability :
WHITE/GREY/BLACK = normal walkways
RED = Kills the player
ORANGE = Turbo
BLUE = Sticky (climable)
BROWN = Moving objects
GREEN = Spawn area

The Void is a collection of jump and run puzzles, flying through loopings, corkscrews, and thinking puzzles. The world is devided in 4 parts, and every part start with a green spawnarea. If you reach such area's, a teleporter shortcut will be made available.

- Michael "Hezus" Jansen                        

(For Legal Issues refer to the information at the end of this file)
===============================================================================

* Installation *
----------------

Unzip this pack into your Half-life folder and everything will be placed right.

===============================================================================

* Map info *
--------------------

Title			: The Void
Filename		: thevoid.zip
Author			: Michael "Hezus" Jansen
E-mail			: hezussupastar@hotmail.com
Web Site		: http://www.goannasvencoop.com/Hezus
Description		: A Map Series for SvenCo-op 3.5

===============================================================================

* Play Information *
--------------------

Game                    : Half-Life / SvenCoop 3.5
Single Player           : Yes
Deathmatch              : no
Difficulty Settings     : no
New Sounds              : no
New Graphics            : Yes
Known bugs		: None

===============================================================================

* Construction *
----------------

Base                    : All new map from scratch
Build Time              : 2 days
Editor used          	: Valve Hammer Editor v3.4  (by Valve ofcourse)
Other Utilities         : ZHLT Compile Tools 3 (Beta 4)
                          ZHLT Compile GUI X2 (Jan Hartung)

===============================================================================

* Credits *
-----------
Textures :
Sph!nx

====================================
          Hezus Mapping
====================================
WebSite : www.goannasvencoop.com/Hezus
Contact : hezussupastar@hotmail.com

====================================
            SvenCo-op
====================================
WebSite : www.svencoop.com
Contact : sven@svencoop.com

=================================================================================
Important Legal Information :
-----------------------------

- I`m NOT responsible for loss of data,limbs,houses,money,angry mum`s,bad weather
  or ANYTHING (except fun and joy ofcourse) when you decide use these files.
- Other Mappers are free to use the custom textures, models, sounds and idea`s
  of the map, but you have to add the authors credits to your readme file, check
  the "Credits" for that.
- Feel free to put this map on custom CD`s/magazines CD`s (or DVD). A notify 
  from the game magazine, that you are using my map, would be nice ! Make sure 
  this readme file and all other files are attached !
- This map is 100 % FREEWARE, that means you cannot just sell it to anyone for
  money ! If you sell it for money it means you owe me the money you gained from it.
  If you payed money to get this, than someone has screwed you ;)
- These files are Copyright of Hezus Mapping ! Publishing it with your name below
  it is NOT allowed !
=================================================================================