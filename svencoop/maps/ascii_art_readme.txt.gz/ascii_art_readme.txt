
ascii_art

Mission:

1:Go to the top of building and push the switch.

2:3 minutes after,incoming the enemys.

3:Go to the under floor and killed all Ascii Art monsters.

4:Go to the ground and killed morimaki.

5:Go to the top of building again and killed konichiwa.

Ascii Art is Internet forum 2channel's Shift JIS arts.



Release date 2008.7.12

MAP by enuze