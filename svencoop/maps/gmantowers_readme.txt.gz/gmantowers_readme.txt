  /\     
   /\     GMAN TOWERS
  /  \/        -By DAN200

=======================
Hi, and thanks for playing GMan Towers, the first released map map by Sven Co-op mapper DAN200, yet considered worthy of entry into the SvenCoop final, which, if you're reading this, has actually come out. Neato! 

Anywho, I assume most of you are reading because of the short notice at the bottom of the MOTD, and for that i say good on you! So, heres that story you've all been waiting for..... just after these short details, heh.

MAP INFO
=========
You have no idea how long it has taken me to peice this map togetber, trust me, its was wayyyyyy to long to be healthy. Thats not to say I didn't enjoy it mind, its just I frequently suffer from Mappers Block, leak paranoia, and lazyness. Anyway, heres all that bog standard info they insist on distributing with these things...

MAP NAME:      GMan Towers
AUTHOR:        DAN200
EMAIL:         DAN200__@Hotmail.com
WEBSITE:       http://www.creepsworld.com/dan200/
GAME:          SvenCoop
R-SPEEDS:      Generally ok, it peaks a bit in the lift shaft, but if youre pc is even half-decent you'll handle it.
BUILD TIME:    Waayyyyy tooo long!!! No, seriously, this is like 6 to 8 months! But It sure did pay off, I
               originally released this may for Svencoop publically where It dominated the 2.0 Beta servers
               for weeks and weeks, it was a bit bugged at that stage but still recieved a 89% review score
               at Creeps SvenCoop, and now its it 2.0 Final!
COMPILE TIME:  Just over an hour on a Duron 850, and if that kinda thing intrests you then you are surely doomed!

Now for what you've all been waiting for, the story, this is farrrr longer (and better written) than the version in the MOTD...

STORY
=========
BACKROUND - -

"The lives of yourself and others may depend on your fitness"
Every day on the twisted journey to work would we hear these eleven words, never once did we think to take it literally. Never ones to take trainride propoganda literally, you and your co-workers were based in and around the Sector G test labs area of the Black Mesa Facility, of cource, you didn't all get along too well back then, the traditional distrust between Science woker and Security Guard prevented such things. That was before March 15th.

In the early morning of the date of March 15th 200- the Black Mesa Research facility was suffering some of the worst technical malfunctions in the documented parts of its history. Security malfunctions, corupted computer files, heck, even the transit network itself was reported to have stopped in its tracks on more than one occasion. Most of the Scientists put it down to a slight power shortage as a result of massive demand from the nearby Sector C labs. They didn't know the half of it.

They weren't wrong mind, The problem was indeed sourced to the Sector C test labs, specifically the Anomalous Materials laboratries where a very large experiment conserning an unusual offworld crystaline sample was taking place. "Power to stage one emmiters in 3, 2, 1." the intercom was saying. "Power to stage two emmiters, now". The equipment was spriraling into life, a impressive display of lasers and beams that even Walt Disney would be proud of. "Sustaining Sequence" it continued. "I've just been informed that the sample is ready Gordan, it should be coming up to you in a few moments".
"Go on, Slot the carrier into the analysis port". Dr. Freeman did exactly as he was told. The experiment blew up in his face. The world of inter dimensional science would never be the same again.

In the days that followed the Black Mesa Research facility was reduced to a wreck as strange alien creatures crossed the tear in the barriers between normaility and the unknown, causing havoc and slaying all those who stood in there way. Needless to say the military were sent in to contain the invasion, as well as silensing those who witnessed the events. The public must not know what had happened, they couldn't know, they musn't.

However, some groups of former co-workers teamed up to combat the invaders from both sides of the portal, but few were successful. You and you're team are part of those few, and while men were lost, you amd your former co-workers, your friends, managed to make it out of the complex alive. Scientists and Security Workers allied together in a fight for freedom, above all else.

NOW - -

It is now 8 weeks since the Black Mesa incident and you and your team have been resting in hinding before seeping back into society. However, you have recieved a letter from a man going by the innitials of LM, claiming to be the administrator of the Black Mesa research facility. At first you were overjoyed, he was on our side, as the leader of the facility before the experiment he is surely your friend and your ally. In his letter he contained instructions for us to visit him in his personal skyscraper in the City. It was a rather large building, 26 floors up if reports are to believed, and you have been instructed to report to the top floor, his office, in order to meet him personally. Apparently, he has been monitoring your progress since the start of all this and is impressed by your teamwork, co-operation and dedication to you're task, and he wishes to propose a Strategic Alliance between yourself and his, ahem, personal forces.

The arranged date and time of said meeting has been met, and you and your fellows are presently waiting outside of the Adminstrators office, where he will discuss your fate... not that you didnt forget to bring your guns mind, safely consealed, just in case.

CREDITS
========
Map by DAN200.
Help, testing and support by Dudda and AndyZ.
Voice Acting by (GIT)r-man and Wintermute.
Sky by Necros.
Oh, and VALVe software and Sven Viking had something to do with it. :)

=========

Thats all for now, remember to visit my website at...
>>> http://www.creepsworld.com/dan200 <<<
For general svencoop I recommend you visit one of these fabulous svencoop links
http://www.svencoop.com              - The official site, duh.
http://www.creepsworld.com/svencoop  - Clearly the best Svencoop fan site there is!
Send any map feedback you might have to DAN200__@Hotmail.com or see me on the SvenCoop Forums.

Enjoy the map!

=========
Copyright 2001-2002 Daniel Ratcliffe.
Not to be distributed seperate to the Svencoop install program. Oh, and dont under any circumstances use this map as a base to build your own, without EXPLICIT permission. Cheers.
=========

I said Enjoy the map dammit!!