-----------------------------------------------------------------------
Map Title:  Red Fang

-----------------------------------------------------------------------
Map Author: - Onox792

-----------------------------------------------------------------------

-=STORY=-
	A mysterious government agent called Silver Smith has stolen a
	valuable crystal from a remote area of Black Mesa for unknown 
	purposes and it is believed that he has hidden in Xen.

	Now you and your squad must get back that crystal, there is a lot
	of alien activity in the many areas of Black Mesa, so be careful.
	The portal through Xen must be near where your team has landed...
-----------------------------------------------------------------------
-=Additional info=-

	3-6 players recommended

-=Special Thanks=-

	Ainaryu for beta testing

	Hezus for some of his prefabs

	Valve
	Gearbox

	and last but not least, all of the
	SC developers.

-----------------------------------------------------------------------
