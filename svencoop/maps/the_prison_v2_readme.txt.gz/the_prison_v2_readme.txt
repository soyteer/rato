The Prison (version 2) - A map for Sven Co-op

This is my first map for Sven Co-op. The mission is to
escape from a high security prison that is guarded by
the military. See the motd for full story.

Releasedates: 2007 03 09 (v1), 2007 06 10 (v2)
Author: Swedish Soldier
Size: Medium
Map description: Walkthrough, prison escape
Recommended amount of players: 2-8
Singleplayer: Yes
Made with: Valve Hammer Editor 3.4
Custom textures/models/sounds: No
Contact: swedishsoldier@gmail.com

To install, unzip the files into your SvenCoop\maps folder.

Changelog version 2:

-Fixed bug with one spawnpoint not working
-Fixed various misaligned/wrong textures
-Increased view distance
-Removed waves on water in sewers
-Added more monsters
-Modified monster properties and placements
-Various modifications in architecture
-Deleted empty func_wall