Zero 
Made By The-Real-Game
---------------------
Detail Stuff
==========
Map Name:	Zero
Bsp Name:       zero.bsp
Game Type:	Half-Life: Sven-Coop
Author:	 	The-Real-Game
E-Mail:	 	therealgame@blueyonder.co.uk
Website:	http://www.therealgame.pwp.blueyonder.co.uk/
Build Time:	About 5 or so months
Compile Time:	35 minutes

Background to the map:

 As alot of forum goers will remember, I first posted news about this map around march of this year.
Originally it was planned to be a 3 map set, however after realising the 3rd map in the set had the most going for it I decided to remove the other maps from the set and just concentrate on the one map.
The first map was released as a seperate map under the name of broken path around june. 

 After alot of work on this map I've finally come to what I now consider the first version worthy of been labeled as a beta. This version is intended to be used for testing with 3.0 and contains a few of the new elements included with 3.0


See zero_storyline.txt for the full story.


The Testers :
----------------
Major Thanks To:

 CreepingDeath for testing and server hosting.
 Xterminate for testing and server hosting.
 Mutant for testing and server hosting.
 Dudda for testing and server hosting.
 BMTwigzta for testing and server hosting.

Thanks to the following for the great feedback / ideas:

 Mad Jonesy
 Sven Viking
 CreepingDeath
 Mutant
 Xterminate
 Commando

Thanks To All The 3.0 beta testers !


Additional thanks to :

tdw
FreakingNeo
Dan200
Alpha571


Software Used :

 Valve Hammer Editor version 3.4/3.5 -  http://www.valve-erc.com/
 Zoners Half Life Tools              -  http://collective.valve-erc.com/index.php?go=mhlt
 Sven Coop 2.1/3.0                   -  http://www.svencoop.com/


 And of course cheers to the whole Sven Coop Team for their awesome mod.
"We're not worthy!!!!" and so forth...

WARNING:
This map and its contents are copyright Gareth Prior.
You may not edit this map in ANY way, form or shape
Nor can you use this map as a base.
If you decide to include this on cds, website, mappack or anything please notify me.
