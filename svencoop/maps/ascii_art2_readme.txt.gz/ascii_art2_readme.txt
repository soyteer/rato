
ascii_art2

Mission:

1:Go to the ground.

2:Go to enemy's building and killed all enemy.

3:Killed all morimaki.

4:Go to the top of building and killed konichiwa.

Night version of ascii_art.



Release date 2008.10.26

MAP by enuze