##################################
# STORY INTRO (cont. from MOTD:
##################################

Five figures walk down a corridor, four of them surrounding the one carrying a lifeless man
in a white Jacket.  The figures have a humanoid form, but that is where the similarities 
end.  Instead of having flesh they have metal plating, four of them being the color of green
while the one in the middle is purple.  The five some head down a corridor with bodies in 
many different death positions.  Some have blue uniforms, others have white lab coats, 
while a couple more wear black military uniforms.  They pick up on a transmission from the
hive mind, asking a question, "Why did they kill my father?"  Unfortunately the metallic
beings lack the intelligence to answer that question.

In a faintly lighted room, five figures dressed in blue sit around a table.  All of them 
holding up cards and staring at each other.  They remain quiet until one of them smiles 
and laughs, causing the rest of them to follow suit.  Suddenly the klaxons flare, a cool 
calm male voice reports, "Alert! Code red, repeat code red.  Communication has been lost 
with ninety eight percent of complex.  All security please report to your stations, this
is not a drill."  Before they can get up, the place shakes violently as they hear a very 
close and loud explosion.  After brief moment of silence, they can hear motors of vehicles
approaching.  They run to their lockers quickly donning their vest and holstering their guns,
some of them sweating.  To them hell has just come and gave a knock at their door.

##################################
# TEXTURES:
##################################
Half-Life
Some Custom

##################################
# PREFABS:
##################################
Trailblazer
by Barney99

##################################
# CONTACT
##################################

vger3781@hotmail.com - Get's lot's of junk mail and I may delete on accident
vger3781@wzrd.com    - Barely gets any mail and would be a good idea to send here.
vger3781@hellzkitchenserver.com - If the other two don't work

Homepages
www.wzrd.com/~vger3781/
odin.prohosting.com/~vger3781/
They should list my E-mail if something happens.

www.svencoop.com/forums/
PM me

##################################
# SPECIAL THANKS
##################################
 
MassAsster
Dementra
Intrepid
Templetion Peck
HeadWard
Wrathful
Fantasie
SkullHockey3
Valentine
Aden
PissDrunk
Skud
AngelMaker
DuDe - Who keeps changing his sn
Kalashnikovo

Fortune2 - For the sky texture 
