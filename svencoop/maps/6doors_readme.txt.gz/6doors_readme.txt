==============================================================
                  ***6doors***
                     
                   by StreamFox 

6doors is medium fun-skill map with a boss fight at the end. 
Each door leads to a room with some obstacles. You only can 
open the next door if you pulled the levers at the previous room 
(at the same time, of course!). After you finished all the six rooms, 
you can open the boss door and activate the main teleport, which 
leads to the final task.

*Four players are required in order to pull the levers in each room!


---------
Install
---------
Just unzip into your Half-Life folder.

----------
Map info
----------
Author:               StreamFox
Email:                streamfox@totalhl.hu
Title:                6doors
File name:            6doors.bsp
Version:              Final
Game:                 Sven Co-op 3.0 / Sven Co-op 4.0 Beta
Type:                 Fun
Players:              min 4 player
Difficulty:           Medium-Hard
Custom sounds:        No
Custom textures:      Yes
Custom models:        No
Bugs:                 No
	   

---------------		   
Additional info
---------------
Map tested by:
Royal-soldier
Kuzum
RNG
Katana

custom robo models: http://www.fpsbanana.com/skins/16203 except
the mini ones.

*I`m NOT responsible for any data loss, game crash or anything.
*This map MUST NOT be sold.
*You MUST NOT publish this map below your name.
*Feel free to put this map to a custom CD/DVD or upload to any LEGAL sites, 
 but make sure every files including this readme are attached!

==============================================================